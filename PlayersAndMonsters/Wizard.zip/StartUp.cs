﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Text;
using System.Threading.Channels;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        Hero emoHero = new Hero("Emo", 10);

        Console.WriteLine(emoHero);
        }
        

       
    }
}
